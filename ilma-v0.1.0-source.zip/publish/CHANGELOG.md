# Changelog

All notable changes to ILMA are documented here.

Format: `[version] — date`
Types: `Added`, `Fixed`, `Changed`, `Removed`

---

## [0.1.0] — 2025

### Added

**Core language (Tier 1 — Seed)**
- `say` — print a value to the screen
- `remember x = value` — declare and assign a variable
- `ask "question"` — read input from the user
- `repeat N:` — repeat a block N times
- `if condition:` / `otherwise:` / `otherwise if condition:` — conditional logic
- `yes` / `no` — boolean values
- `empty` — the absence of a value
- `and`, `or`, `not` — logical operators
- `is` / `is not` — equality checks
- Full arithmetic: `+`, `-`, `*`, `/`, `%`
- Comparison operators: `<`, `>`, `<=`, `>=`
- String concatenation with `+`
- Comments with `#`

**Core language (Tier 2 — Sapling)**
- `recipe name(params):` — define a reusable function
- `give back value` — return a value from a recipe
- `bag[item, item, ...]` — ordered list
- `bag.add(item)`, `bag.remove(item)`, `bag.size`, `bag.sorted()`, `bag.contains(item)`
- `notebook[key: value, ...]` — key-value store
- `notebook[key]` — get a value by key
- `for each item in collection:` — loop over a bag or notebook
- `keep going while condition:` — conditional loop

**Core language (Tier 3 — Tree)**
- `blueprint Name:` — define a class
- `create(params):` — constructor (called automatically on instantiation)
- `me.field` — refer to the current object's own fields
- `blueprint Child comes from Parent:` — inheritance
- `comes_from.create(...)` — call the parent constructor
- `use module_name` — import a standard library module
- `shout "message"` — raise an error
- `try:` / `when wrong:` — error handling

**Type system**
- Inferred typing for all values (no declaration needed)
- Optional explicit types: `whole`, `decimal`, `text`, `truth`, `bag`, `notebook`, `anything`
- Full Unicode identifier support (Arabic, Urdu, and all UTF-8 scripts)

**Compiler**
- ILMA → C transpilation (generates clean, readable C)
- Native binary compilation via GCC
- `ilma file.ilma` — compile and run
- `ilma --compile file.ilma` — compile to binary only
- `ilma --c file.ilma` — show generated C code
- `ilma --tokens file.ilma` — show token stream (debugging)
- `ilma --version` — show version
- `ILMA_HOME` environment variable for custom runtime path

**Runtime**
- `IlmaValue` tagged union for all value types
- Managed strings with automatic memory handling
- Dynamic bags (arrays) with O(1) amortised append
- Hash map notebooks with string keys
- Error handling via `setjmp`/`longjmp`
- Friendly error messages for runtime failures

**Testing**
- 17 tier-1 test programs with expected output verification
- `make test` and `make test-verbose` targets

**Tooling**
- `Makefile` with `all`, `test`, `install`, `uninstall`, `clean`
- `install.sh` — one-command installer for Linux and macOS
- GitHub Actions CI (Ubuntu + macOS)
- GitHub Actions Release (Linux x86\_64, Linux ARM64, macOS universal, Windows)

---

## Roadmap

### [0.2.0] — planned
- `finance` standard library module (compound interest, zakat, budgeting)
- `time` standard library module (Hijri calendar, prayer times, date arithmetic)
- `think` standard library module (decision matrices, stoic prompts)
- Improved error messages with line/column highlighting
- `for each key, value in notebook:` — iterate notebook entries
- String methods: `.upper()`, `.lower()`, `.contains()`, `.split()`
- Multi-line strings

### [0.3.0] — planned
- `body` standard library module (BMI, sleep, health tracking)
- `quran` standard library module (text, search, ayah of the day)
- `draw` standard library module (2D graphics, Islamic geometric art)
- Package manager: `ilma install <package>`
- ILMA → WebAssembly compilation target

### [0.4.0] — planned
- In-browser IDE at ilmalang.dev
- Language Server Protocol (LSP) for editor support
- Windows native binary (no WSL required)
- Tier 2 curriculum: 30 lesson modules

### [1.0.0] — planned
- Stable language specification (no breaking changes after this)
- `science`, `trade`, `law` standard library modules
- ILMA Web framework
- ILMA Mobile compilation target
