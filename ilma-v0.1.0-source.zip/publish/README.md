# ILMA

**A programming language for children, families, and the next generation.**

ILMA is a complete programming language that reads like plain English. It is built on C for maximum performance and portability, inspired by Python's simplicity, but designed fresh — every keyword was chosen so that a child reading their first line of code immediately understands what it does.

**[ilmalang.dev](https://ilmalang.dev)** · [Documentation](https://ilmalang.dev/docs) · [Examples](https://ilmalang.dev/examples)

---

## A taste of ILMA

```ilma
# Your first program
say "Bismillah"
remember name = ask "What is your name? "
say "Assalamu Alaikum, " + name

# Recipes (functions)
recipe greet(person):
    give back "Welcome, " + person

say greet("Yusuf")

# Bags (lists)
remember fruits = bag["dates", "mango", "apple"]
for each fruit in fruits:
    say fruit

# Blueprints (classes)
blueprint Animal:
    create(name, sound):
        me.name  = name
        me.sound = sound

    recipe speak():
        say me.name + " says " + me.sound

remember cat = Animal("Cat", "Meow")
cat.speak()
```

Every concept maps to something real. Variables are things the program **remembers**. Functions are **recipes** with inputs. A class is a **blueprint**. You refer to yourself as **me**. Errors are **shouted**. Nothing is **empty**.

---

## Install

### One-line install (Linux and macOS)

```bash
curl -fsSL https://ilmalang.dev/install.sh | bash
```

### Build from source

```bash
git clone https://github.com/ilmalang/ilma
cd ilma
make
sudo make install
```

**Requirements:** GCC, Make. That is all.

### Windows

Use [WSL (Windows Subsystem for Linux)](https://learn.microsoft.com/en-us/windows/wsl/install) and follow the Linux install instructions, or download a binary from [Releases](https://github.com/ilmalang/ilma/releases).

---

## Usage

```bash
ilma hello.ilma              # Run an ILMA program
ilma --compile hello.ilma    # Compile to a binary
ilma --c hello.ilma          # Show generated C code
ilma --tokens hello.ilma     # Debug: show token stream
ilma --version               # Show version
ilma --help                  # Show help
```

---

## How it works

ILMA compiles your `.ilma` source file to clean, readable C code, then uses your system's GCC to produce a native binary. The entire round trip happens in milliseconds. You get C-level performance with a syntax a child can read.

```
hello.ilma  →  ILMA compiler  →  hello.c  →  GCC  →  hello (binary)
```

---

## The keyword philosophy

Every keyword in ILMA was chosen from scratch. Nothing was borrowed from other languages.

| ILMA | Meaning | Other languages say |
|------|---------|---------------------|
| `remember x = 5` | A variable — the program remembers this | `let`, `var`, `int x =` |
| `recipe greet():` | A reusable skill with inputs | `def`, `function`, `fn` |
| `give back` | Return a value | `return` |
| `blueprint Dog:` | A class definition | `class` |
| `me.name` | Refer to own field | `self.`, `this.` |
| `comes from Animal` | Inherit from parent | `extends`, `inherits` |
| `shout "error"` | Raise an error | `raise`, `throw` |
| `when wrong:` | Handle an error | `except:`, `catch {}` |
| `use finance` | Import a module | `import`, `#include` |
| `yes` / `no` | Boolean values | `True`/`False`, `true`/`false` |
| `empty` | Null value | `None`, `null`, `nil` |
| `bag[...]` | A list | `[]`, `list()` |
| `notebook[...]` | A key-value store | `{}`, `dict()` |

---

## Language tiers

ILMA has one grammar with three depth levels that reveal naturally as the learner grows:

| Tier | Ages | Focus |
|------|------|-------|
| **Seed** (Tier 1) | 3–7 | `say`, `remember`, `repeat`, `if/otherwise` |
| **Sapling** (Tier 2) | 7–13 | `recipe`, `bag`, `notebook`, `for each`, knowledge modules |
| **Tree** (Tier 3) | 13+ | `blueprint`, `comes from`, `try/shout/when wrong`, modules |

---

## Standard library modules

ILMA's standard library teaches real-world knowledge through code:

```ilma
use finance
remember result = finance.compound(principal: 1000, rate: 0.05, years: 10)
say "After 10 years: " + result

use time
say time.to_hijri(time.today())

use think
remember choice = think.weigh("Study now or play?")
```

Planned modules: `finance`, `time` (Hijri calendar), `think` (logic and stoicism), `body` (health), `quran`, `trade`, `draw`, `science`, `web`.

---

## Building and testing

```bash
make              # Build the compiler
make test         # Run the test suite
make test-verbose # Run tests with full output
make install      # Install to /usr/local
make uninstall    # Remove from system
make clean        # Clean build artifacts
```

---

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `ILMA_HOME` | auto-detected | Override runtime library path |

---

## Project structure

```
ilma/
├── src/
│   ├── main.c            # CLI entry point
│   ├── lexer.c / .h      # Tokeniser
│   ├── parser.c / .h     # Recursive descent parser
│   ├── ast.c / .h        # Abstract Syntax Tree
│   ├── codegen.c / .h    # C code generator
│   └── runtime/
│       ├── ilma_runtime.c # Core value types, bags, notebooks, GC
│       └── ilma_runtime.h
├── tests/
│   └── tier1/            # .ilma test files + .expected outputs
├── examples/             # Example ILMA programs
├── Makefile
├── install.sh
└── README.md
```

---

## Contributing

ILMA is open source and welcomes contributions.

```bash
git clone https://github.com/ilmalang/ilma
cd ilma
make && make test   # Make sure everything passes first
```

Good first contributions:
- Add test cases to `tests/tier1/`
- Implement a standard library module in `src/runtime/`
- Improve error messages in `src/parser.c`
- Add examples to `examples/`

Open an issue before working on large changes so we can discuss the approach.

---

## Roadmap

- [x] Tier 1: `say`, `remember`, `ask`, `repeat`, `if/otherwise`, `recipe`, `give back`
- [x] Tier 2: `bag`, `notebook`, `for each`, `keep going while`, blueprints
- [x] Tier 3: `blueprint`, `comes from`, `try/shout/when wrong`
- [ ] Standard library: `finance`, `time`, `think`, `body`, `quran`
- [ ] Web platform: in-browser IDE at ilmalang.dev
- [ ] Package manager: `ilma install <package>`
- [ ] Language server protocol (LSP) for editor support
- [ ] Windows native binary
- [ ] ILMA → WebAssembly compilation target

---

## License

MIT License. See [LICENSE](LICENSE).

---

## Author

Created with the intention of giving every child — regardless of background, geography, or school system — access to the tools of the knowledge economy.

*"Read. In the name of your Lord who created."* — Al-Alaq 96:1
